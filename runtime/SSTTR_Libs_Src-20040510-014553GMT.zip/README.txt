All files in this package are the copyright of their respective authors.  See the files
themselves for more details.  In the event a file does not include a license or copyright
statement then the copyright and license in LICENSE.txt applies by default.

Sorry, nothing else to say at this time.
