/*
 * TEA.java
 *
 * This code is considered Public Domain based on the statement provided with the original code.
 * See the comments bellow for more details.
 *
 * Created on May 2, 2003, 11:46 PM
 */

package com.ssttr.crypto;

import com.ssttr.util.Strings;

/**
 * This is a 100% Pure Java implementation of the Tiny Encryption Algorithm which
 * can be found <a href="http://vader.brad.ac.uk/tea/tea.shtml">http://vader.brad.ac.uk/tea/tea.shtml</a>.
 * Or at least that's where I originaly found it.  It appears that it is still available
 * here: <a href="http://www.simonshepherd.supanet.com/tea.htm">http://www.simonshepherd.supanet.com/tea.htm</a>.
 * <p>
 * TEA is only capable of using 128 bit keys.  If any other key length is desired
 * you will have to pad or chop (as appropriate) the key to be 128 bits long.
 * <p>
 * It was ported from the ANSI C new variant <a href="http://vader.brad.ac.uk/tea/source.shtml#new_ansi">http://vader.brad.ac.uk/tea/source.shtml#new_ansi</a>.
 * As I mentioned above, that page seems to have disappeard, so here's the new equivelent:
 * <a href="http://www.simonshepherd.supanet.com/source.htm#new_ansi">http://www.simonshepherd.supanet.com/source.htm#new_ansi</a>.
 * In case the original page goes down it's copied below:
 * <p>
 * Please feel free to use any of this code in your applications. The TEA
 * algorithm (including new-variant TEA) has been placed in the public domain, as have my assembly
 * language implementations. <p><hr>
 * <p>
 * <pre>
 * void encipher(const unsigned long *const v,unsigned long *const w,
 * const unsigned long * const k)
 * {
 *    register unsigned long       y=v[0],z=v[1],sum=0,delta=0x9E3779B9,
 * 				a=k[0],b=k[1],c=k[2],d=k[3],n=32;
 * 
 *    while(n--&gt;0)
 *       {
 *       sum += delta;
 *       y += (z &lt;&lt; 4)+a ^ z+sum ^ (z &gt;&gt; 5)+b;
 *       z += (y &lt;&lt; 4)+c ^ y+sum ^ (y &gt;&gt; 5)+d;
 *       }
 * 
 *    w[0]=y; w[1]=z;
 * }
 * 
 * void decipher(const unsigned long *const v,unsigned long *const w,
 *    const unsigned long * const k)
 * {
 *    register unsigned long       y=v[0],z=v[1],sum=0xC6EF3720,
 * 				delta=0x9E3779B9,a=k[0],b=k[1],
 * 				c=k[2],d=k[3],n=32;
 * 
 *    // sum = delta&lt;&lt;5, in general sum = delta * n
 * 
 *    while(n--&gt;0)
 *       {
 *       z -= (y &lt;&lt; 4)+c ^ y+sum ^ (y &gt;&gt; 5)+d;
 *       y -= (z &lt;&lt; 4)+a ^ z+sum ^ (z &gt;&gt; 5)+b;
 *       sum -= delta;
 *       }
 *    
 *    w[0]=y; w[1]=z;
 * }
 * 
 * 
 * </pre>
 * @author  smeiners
 */

public class TEA
implements SKEncryption
{
    /** Default number of iterations to perform durring encryption/decryption (32). */
    public static final  int    DEFAULT_ITERATIONS = 32;
    
    private int[]               key     = null;
    private static final int    delta   = 0x9E3779B9;
    private static final int    SUM     = 0xC6EF3720;
    private int                 cycles  = DEFAULT_ITERATIONS;
    
    /** Creates a new instance of TEA */
    public TEA ()
    {
    }
    
    /**
     * Creates a new instance of TEA.
     *
     * @param cycles The number of iterations to perform durring encryption/decryption.  If iterations < 6 the default will be used.
     */
    public TEA (int iterations)
    {
        if( iterations >= 6 )
            cycles = iterations;
    }
    
    public int getIterations()
    { return cycles; }
    
    /**
     * Sets the encryption key to be used.
     *
     * @param key The key as a hexidecimal string.
     * @throws IllegalArgumentException if <code>key.length() != 32</code>.
     */
    public void setHexKey(String key)
    {
        setKey( Strings.fromHex(key) );
    }
    
    /**
     * Sets the encryption key to be used.
     *
     * @param key The key in raw (non-hex) byte form.
     * @throws IllegalArgumentException if <code>key.length != 16</code>.
     */
    public void setKey (byte[] key)
    {
        if( key.length != 16 )
            throw new IllegalArgumentException("key.length != 16");
        
        this.key = toInts(key);
    }
    
    /**
     * Encrypts some data.
     *
     * @param rawData The data to be encrypted (binary data is ok).
     * @return Encrypted data.
     * @throws IllegalArgumentException if rawData.length == 0
     */
    public byte[] encrypt (byte[] rawData)
    {
        if( rawData.length == 0 )
            throw new IllegalArgumentException("rawData.length == 0");
        
        if( rawData.length % 8 != 0 )
        {
            // pad the data out to the 8 byte boundry with 0's
            byte[] tmp = new byte[ rawData.length + ( 8 - (rawData.length % 8) ) ];
            System.arraycopy( rawData, 0, tmp, 0, rawData.length );
            for( int i = rawData.length; i < tmp.length; i ++ )
                tmp[i] = 0;
            rawData = tmp;
        }
        
        int[] in = toInts(rawData);
        int[] out = new int[in.length];
        
        for( int i = in.length - 2; i >= 0; i -= 2 )
            encipher(in, out, i);
        
        return toBytes(out);
    }
    
    /**
     * Decrypts some data.
     *
     * @param cryptedData The data to be decrypted.
     * @return The original rawData that was previously encrypted.
     * @throws IllegalArgumentException if cryptedData.length == 0
     */
    public byte[] decrypt (byte[] cryptedData)
    {
        if( cryptedData.length == 0 )
            throw new IllegalArgumentException("cryptedData.length == 0");
        
        int[] in = toInts(cryptedData);
        int[] out = new int[in.length];
        
        for( int i = in.length - 2; i >= 0; i -= 2 )
            decipher(in, out, i);
        
        byte[] data = toBytes(out);

        int z = data.length - 1;
        
        if( data[z] != 0 )
            return data;
        
        for( ; data[z] == 0 && z >= 0; z -- );  // find the end of the 0 padding

        z++; // add one to change the index to the length
        
        byte[] u = new byte[z];
        System.arraycopy(data, 0, u, 0, z);
        
        return u;
    }
    
    private final void encipher(final int[] in, final int[] out, final int offset)
    {
        int     y   = in[offset],
                z   = in[offset+1],
                sum = 0,
                n   = cycles;

        while( n-- > 0 )
        {
            y += (z << 4 ^ z >> 5) + z ^ sum + key[sum&3];
            sum += delta;
            z += (y << 4 ^ y >> 5) + y ^ sum + key[sum>>11 & 3];
        }

        out[offset]      = y;
        out[offset+1]    = z;
    }

    private final void decipher(final int[] in, final int[] out, final int offset)
    {
        int     y   = in[offset],
                z   = in[offset+1],
                sum = SUM,
                n = cycles;

        /* sum = delta<<5, in general sum = delta * n */

        while( n-- > 0 )
        {
            z -= (y << 4 ^ y >> 5) + y ^ sum + key[sum>>11 & 3];
            sum -= delta;
            y -= (z << 4 ^ z >> 5) + z ^ sum + key[sum&3];
        }

        out[offset]      = y;
        out[offset+1]    = z;
    }
    
    private static int[] toInts(byte[] bytes)
    {
        int i, j;
        
        i = bytes.length / 4;
        int[] ints = new int[i];
        
        for( i --, j = bytes.length - 1; i >= 0; i -- )
        {
            ints[i] =   ( bytes[j--] & 0xFF ) << 24 |
                        ( bytes[j--] & 0xFF ) << 16 |
                        ( bytes[j--] & 0xFF ) << 8  |
                        ( bytes[j--] & 0xFF );
        }
        
        return ints;
    }
    
    private static byte[] toBytes(int[] ints)
    {
        int i, j;
        
        i = ints.length * 4;
        byte[] bytes = new byte[i];
        
        for( i --, j = ints.length - 1; j >= 0; j -- )
        {
            bytes[i--] = (byte)( ( ints[j] >> 24 ) & 0xFF);
            bytes[i--] = (byte)( ( ints[j] >> 16 ) & 0xFF);
            bytes[i--] = (byte)( ( ints[j] >> 8  ) & 0xFF);
            bytes[i--] = (byte)(   ints[j]         & 0xFF);
        }
        
        return bytes;
    }
    
}
