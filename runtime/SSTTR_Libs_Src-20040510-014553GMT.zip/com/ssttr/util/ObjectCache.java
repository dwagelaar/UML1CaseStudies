/*
 * ObjectCache.java
 *
 * Created on June 30, 2003, 11:59 AM
 * Copyright (c) 2003, Sean M. Meiners, sean@ssttr.com
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of SSTTR nor the names of its contributors may be used
 *       to endorse or promote products derived from this software without specific
 *       prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.ssttr.util;

import java.io.IOException;

import java.util.Map;
import java.util.Iterator;
import java.util.WeakHashMap;

/**
 * Implements a simple Object cache based on a <code>WeakHashMap</code>.
 * @author  smeiners
 */
public class ObjectCache
{
    
    protected Map               cachedObjects           = new WeakHashMap(11);
    protected ObjectFactory     objectFactory           = null;
    
    /** Creates a new instance of ObjectCache */
    public ObjectCache ()
    {
    }
    
    /** Creates a new instance of ObjectCache that will use an <code>ObjectFactory</code> to create a new object if one can not be found in the cache. */
    public ObjectCache (final ObjectFactory objectFactory)
    {
        if( objectFactory == null )
            throw new NullPointerException("objectFactory");
        this.objectFactory = objectFactory;
    }
    
    /** Caches the given <code>Object</code> for retrived with <code>key</code>*/
    public void cache(Object key, Object object)
    {
        cachedObjects.put( key, object );
    }
    
    /** Attempts to retrieve the <code>Object</code> stored under <code>key</code>. */
    public Object get(Object key)
    {
        return cachedObjects.get( key );
    }
    
    /** Attempts to retrieve the <code>Object</code> stored under <code>key</code> and will attempt to create a new one if none is found in the cache.
     * @param param The parameter(s) to pass to the ObjectFactory if a new <code>Object</code> is to be created.
     */
    public Object get(Object key, Object param)
        throws IOException
    {
        Object object = cachedObjects.get( key );
        
        if( object == null && objectFactory != null )
            object = objectFactory.createObject(key,param);
        if( object == null )
            return null;
        
        cachedObjects.put(key, object);
        return object;
    }
    
    /** Removes the <code>Object</code> stored under <code>key</code> */
    public void remove(Object key)
    {
        cachedObjects.remove(key);
    }
    
    /** Returns an <code>Iterator</code> over the <code>key</code>s of the cache. */
    public Iterator iterateKeys()
    {
        return cachedObjects.keySet().iterator();
    }
    
    /** Completely empties the cache. */
    public void flush()
    {
        cachedObjects = new WeakHashMap(11);
    }
    
}
