/*
 * Configuration.java
 *
 * Created on June 18, 2003, 3:25 PM
 * Copyright (c) 2003, Sean M. Meiners, sean@ssttr.com
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of SSTTR nor the names of its contributors may be used
 *       to endorse or promote products derived from this software without specific
 *       prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.ssttr.util;

import java.lang.reflect.Constructor;

import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import com.ssttr.xml.XMLElement;
import com.ssttr.xml.DOMParser;
import com.ssttr.xml.ParserException;

import com.ssttr.util.Strings;
import com.ssttr.util.IllegalPropertyNameException;


/**
 * Here we have a class that makes working with heirarchical XML
 * configuration files as easy as pie (cream pie, not apple, that's
 * too much work).  The idea is that it takes some of the
 * simpler data types and marshals them into a format that's both
 * compatible with XML and fairly human-readable.
 * <br>
 * You may have noticed, as I did, that it's very common to name
 * properties in a Java in a pseudo-heirarchical fashion.  Well,
 * I decided to take it the extra step and make it truly heirarchical.
 * Each property name is really a path through the tree.  For example
 * the property 'window.main.position.x' would map to the XML:
 * <br>
 * <pre>
 *   &lt;windows&gt;
 *     &lt;main&gt;
 *       &lt;position&gt;
 *         &lt;x type='Integer'&gt;42&lt;/x&gt;
 *       &lt;/position&gt;
 *     &lt;/main&gt;
 *   &lt;/windows&gt;
 * </pre>
 * <br>
 * and <code>getProperty('window.mail.position.x')</code> would
 * return an Integer object (java.lang.Integer specificaly).
 * Oh, and calling <code>setProperty('windows.mail.position.x',new Integer(42))</code>
 * would generate the above XML, as you might expect.
 * 
 * @author  smeiners
 */
public class Configuration
{
    /*
     * These are the types that require extra processing.
     */
    private static final Vector     complexTypes    = new Vector(4);
    static{
        complexTypes.addElement("List");
        complexTypes.addElement("Map");
        complexTypes.addElement("XML");
        complexTypes.addElement("Include");
    }
    
    /*
     * These are the types that can be read, but not written.
     */
    private static final Vector     immutableTypes  = new Vector(1);
    static{
        immutableTypes.addElement("Include");
    }
    
    /*
     * This is the token used to separate the elements.
     */
    private static final    char        token   = '.';
    private static final    String      tokenS  = ".";
    
    protected               XMLElement  doc     = new XMLElement("falseroot");
    protected               File        file    = null;
    
    /**
     * Creates a new instance of Configuration that has no
     * backing store and no properties.
     */
    public Configuration ()
    {
    }
    
    /**
     * Creates a new instance of Configuration that loads and saves
     * (when asked) it's data to the specified file.
     */
    public Configuration (String file)
        throws IOException
    {
        this(new File(file));
    }
    
    /**
     * Creates a new instance of Configuration that loads and saves
     * (when asked) it's data to the specified file.
     */
    public Configuration (File file)
        throws IOException
    {
        setFile(file);
        load(new FileInputStream(file));
    }
    
    /**
     * Creates a new instance of Configuration that reads from the
     * specified InputStream untill EOF and uses the data to fill
     * its list of properties.
     */
    public Configuration(InputStream in)
        throws IOException
    {
        load(in);
    }
    
    /**
     * Creates a new instance of Configuration that uses the passed
     * XML DOM as its initial data.
     */
    public Configuration(XMLElement documentRoot)
    {
        load(documentRoot);
    }

    /**
     * Sets the name of the file to be used when saving the data. 
     */    
    public void setFile(String file)
        throws IOException
    {
        setFile(new File(file));
    }
    
    /**
     * Sets the file to be used when saving the data. 
     */    
    public void setFile(File file)
    {
        this.file = file;
    }
    
    /**
     * Reads from the specified InputStream untill EOF and uses
     * the data to fill its list of properties.
     */
    public void load(InputStream in)
        throws IOException
    {
        try
        {
            XMLElement el;
            doc = new XMLElement("falseroot");
            synchronized (doc)
            {
                while( in.available() > 0 )
                {
                    el = new DOMParser().parse(in);
                    if( el != null )
                        doc.addChild(el);
                }
            }
        }
        catch( ParserException x )
        { throw new IOException(x.getMessage()); }
    }
    
    /**
     * Uses the passed XML DOM as a properties source.
     */
    public void load(XMLElement documentRoot)
    {
        doc = documentRoot.copyDeep();
    }
    
    /**
     * Attempts to write the current state of the Configuration
     * to whatever file is configured.
     */
    public void store()
        throws IOException
    {
        if( file == null )
            throw new IOException("No file to store.");
        
        store(new FileOutputStream(file));
    }
    
    /**
     * Attempts to write the current state of the Configuration
     * to the specified OutputStream.
     */
    public void store(OutputStream out)
        throws IOException
    {
        for( Enumeration en = doc.enumerateChildren(); en.hasMoreElements(); )
            out.write(((XMLElement)en.nextElement()).toString().getBytes());
        
        out.close();
    }
    
    /**
     * Writes the current state of the Configuration
     * to the specified XML DOM.
     */
    public void store(XMLElement documentRoot)
    {
        for( Enumeration en = doc.enumerateChildren(); en.hasMoreElements(); )
            documentRoot.addChild( ((XMLElement)en.nextElement()).copyDeep() );
    }
    
    /**
     * Gets the spcified property or returns <code>defaultValue</code>
     * if no such property exists.
     */
    public Object getProperty(String key, Object defaultValue)
        throws IllegalPropertyNameException
    {
        Object o = getProperty(key);
        if( o == null )
            return defaultValue;
        else
            return o;
    }
    
    /**
     * Gets the spcified property or returns <code>null</code>
     * if no such property exists.
     */
    public Object getProperty(String key)
        throws IllegalPropertyNameException
    {
        XMLElement el = findProperty(key,false);
        if( el == null )
            return null;

        return getProperty(el);
    }
    
    private Object getProperty(XMLElement el)
    {
        final String type = getPropertyType(el);
        
        if( type.equals("String") )
            return getPropertyString(el);
        else if( type.equals("Boolean") )
            return getPropertyBoolean(el);
        else if( type.equals("List") )
            return getPropertyList(el);
        else if( type.equals("Map") )
            return getPropertyMap(el);
        else if( type.equals("XML") )
            return getPropertyXML(el);
        else if( type.equals("Include") )
            return getPropertyFile(el);
        else if( type.equals("Byte") )
            return getPropertyNumber(type,el);
        else if( type.equals("Short") )
            return getPropertyNumber(type,el);
        else if( type.equals("Integer") )
            return getPropertyNumber(type,el);
        else if( type.equals("Long") )
            return getPropertyNumber(type,el);
        else if( type.equals("Float") )
            return getPropertyNumber(type,el);
        else if( type.equals("Double") )
            return getPropertyNumber(type,el);
        else if( type.equals("BigDecimal") )
            return getPropertyNumber(type,el);
        else if( type.equals("BigInteger") )
            return getPropertyNumber(type,el);
        else
            return getPropertyString(el);
    }
    
    /**
     * Sets the specified property the specified value.
     */
    public void setProperty(String key, Object value)
        throws IllegalPropertyNameException
    {
        if( key == null || value == null )
            return;
        
        synchronized (doc)
        {
            XMLElement el = findProperty(key,true);
            setProperty(el,value);
        }
    }
    
    private void setProperty(XMLElement el, Object value)
    {
        if( value == null )
            return;
            
        if( value instanceof String )
        {
            setPropertyType(el,"String");
            setPropertySimple(el,value);
        }
        else if( value instanceof Vector )
        {
            setPropertyType(el,"List");
            setPropertyList(el,(Vector)value);
        }
        else if( value instanceof Hashtable )
        {
            setPropertyType(el,"Map");
            setPropertyMap(el,(Hashtable)value);
        }
        else if( value instanceof Number )
        {
            setPropertyType(el,value.getClass());
            setPropertySimple(el,value);
        }
        else if( value instanceof Boolean )
        {
            setPropertyType(el,"Boolean");
            setPropertySimple(el,value);
        }
        else if( value instanceof XMLElement )
        {
            setPropertyType(el,"XML");
            setPropertyXML(el,(XMLElement)value);
        }
        else if( value instanceof Configuration )
        {
            setPropertyType(el,"Include");
            setPropertyFile(el,(Configuration)value);
        }
        else
        {
            setPropertyType(el,"String");
            setPropertySimple(el,value);
        }
    }
    
    /**
     * Removes the specified property.
     */
    public Object removeProperty(String key)
    {
        int last = key.lastIndexOf(token);
        final String parentS = ( last > 0 ? key.substring(0,last) : "" );
        final String childS = ( last > 0 ? key.substring(last+1) : key );
        
        XMLElement parent = null;
        if( parentS.length() < 1 )
            parent = doc;
        else
            parent = findProperty(parentS,false);
        
        if( parent == null )
            return null;

        XMLElement child = parent.getChild(childS);
        final Object old = getProperty(child);
        
        parent.removeChild(childS);
        
        return old;
    }
    
    private XMLElement findProperty(String key, boolean create)
        throws IllegalPropertyNameException
    {
        if( doc == null )
            return null;
        
        if( key.length() < 1 )
        {
            if( doc.getChildCount() == 1 )
                return doc.getChild(0);
            else
                return null;
        }
        
        return findProperty( this, key, Strings.tokenize(key,token), 0, create );
    }
    
    private static XMLElement findProperty( Configuration config, String key, Vector parts, int pos, boolean create )
        throws IllegalPropertyNameException
    {
        String      part    = null,
                    type    = null;
        XMLElement  el      = config.doc,
                    tmp     = null;
        final int   last    = parts.size() - 1;
        
        for( int i = pos; i <= last; i ++ )
        {
            part = (String)parts.elementAt(i);
            tmp = el.getChild(part);
            
            if( tmp == null )
            {
                if( create )
                    tmp = el.addChild(part);
                else
                    return null;
            }
            
            else if( i < last )
            {
                type = getPropertyType(tmp);
                if( type.equals("Include") )
                {
                    Configuration subConfig = config.getPropertyFile(tmp);
                    return findProperty( subConfig, key, parts, i, create );
                }
                // don't retrieve keys from within complex types.
                if( complexTypes.contains(type) )
                    throw new IllegalPropertyNameException(key);
            }
            
            el = tmp;
        }
        
        return el;
    }
    
    /**
     * Gets the type of the specified property.  This is mostly
     * for internal use, but can be occasionally useful to query
     * the type of a property before retrieving it.  Oh, and it
     * will return null if the property doesn't exist. 
     */
    public String getPropertyType(String key)
    {
        XMLElement el = findProperty(key,false);
        if( el == null )
            return null;
        return getPropertyType(el);
    }
    
    private static final String getPropertyType(XMLElement el)
    {
        final String type = el.getAttribute("type");
        
        if( type != null && type.length() > 0 )
            return type;
        
        return "";
    }
    
    private static final void setPropertyType(XMLElement el, String type)
    {
        el.setAttribute("type",type);
    }
    
    private static final void setPropertyType(XMLElement el, Class type)
    {
        String cName = type.getName();
        int lDot = cName.lastIndexOf('.');
        if( lDot > 0 )
            cName = cName.substring(lDot+1);
        
        el.setAttribute("type",cName);
    }
    
    /**
     * The enumerates over every property in the Configuration.
     * This will NOT enumerate any keys from Included files.
     */
    public Enumeration enumerateKeys()
    {
        Vector keys = new Vector();
        
        XMLElement child;
        for( Enumeration en = doc.enumerateChildren(); en.hasMoreElements(); )
        {
            child = (XMLElement)en.nextElement();
            recurseTree( child.getName(), child, keys);
        }
        
        return keys.elements ();
    }
    
    private static final void recurseTree(String key, XMLElement el, Vector keys)
    {
        final String type = el.getAttribute("type");

        // If the tag has a value, or type is set, then it's an endpoint
        if( type != null || ( el.getValue() != null && el.getValue().length() > 0 ) )
            keys.addElement(key);

        // Don't recurse into complex types (like List, Map, and XML)
        if( type != null && complexTypes.contains(type) )
            return;
        
        XMLElement child;
        for( Enumeration en = el.enumerateChildren(); en.hasMoreElements(); )
        {
            child = (XMLElement)en.nextElement();
            recurseTree( key + tokenS + child.getName(), child, keys);
        }
    }
    
    private String getPropertyString(XMLElement el)
    {
        String value = el.getValue();
        if( value == null || value.length() < 1 )
            return null;
        else
            return value;
    }
    
    private void setPropertySimple(XMLElement el, Object value)
    {
        el.setValue(value.toString());
    }
    
    private Boolean getPropertyBoolean(XMLElement el)
    {
        if( el.getValue() != null )
            return Boolean.valueOf(el.getValue());
        else
            return Boolean.valueOf(false);
    }
    
    private Object getPropertyNumber(String type, XMLElement el)
    {
        final String value = el.getValue();
        if( value == null || value.length() < 1 )
            return null;
        
        try
        {
            if( type.startsWith("Big") )
                type = "java.math." + type;
            else
                type = "java.lang." + type;
            
            Class clazz = Class.forName (type);
            Constructor constructor = clazz.getConstructor( new Class[]{ String.class } );
            return constructor.newInstance(new String[]{ value });
        }
        catch( Exception x )
        { }
        
        return null;
    }
    
    private Vector getPropertyList(XMLElement el)
    {
        Vector vec = new Vector();
        XMLElement item;

        for( Enumeration en = el.enumerateChildren(); en.hasMoreElements(); )
        {
            item = (XMLElement)en.nextElement();
            if( ! item.getName().equals("item") )
                continue;
            vec.addElement( getProperty(item) );
        }

        return vec;
    }
    
    private void setPropertyList(XMLElement el, Vector value)
    {
        el.setAttribute("type","List");
        el.removeChildren();
        
        XMLElement item;
        for( Enumeration en = value.elements(); en.hasMoreElements(); )
        {
            item = new XMLElement("item");
            setProperty(item, en.nextElement() );
            el.addChild(item);
        }
    }
    
    private Hashtable getPropertyMap(XMLElement el)
    {
        Hashtable table = new Hashtable();
        XMLElement item;
        Object k,v;
        for( Enumeration en = el.enumerateChildren(); en.hasMoreElements(); )
        {
            item = (XMLElement)en.nextElement();
            if( ! item.getName().equals("item") )
                continue;
            
            k = getProperty( item.getChild("key") );
            v = getProperty( item.getChild("value") );
            if( k != null && v != null )
                table.put(k,v);
        }

        return table;
    }
    
    private void setPropertyMap(XMLElement el, Hashtable map)
    {
        el.setAttribute("type","Map");
        el.removeChildren();

        XMLElement item, kE, vE;
        Object k, v;
        
        for( Enumeration en = map.keys(); en.hasMoreElements(); )
        {
            k = en.nextElement();
            v = map.get(k);

            item = new XMLElement("item");
            
            kE = new XMLElement("key");
            setProperty(kE,k);
            
            vE = new XMLElement("value");
            setProperty(vE,v);
            
            item.addChild(kE);
            item.addChild(vE);

            el.addChild(item);
        }
    }
    
    private XMLElement getPropertyXML(XMLElement el)
    {
        return el.getChild(0).copyDeep();
    }
    
    private void setPropertyXML(XMLElement el, XMLElement xml)
    {
        el.setAttribute("type","XML");
        el.removeChildren();
        
        el.addChild(xml.copyDeep());
    }
    
    private Configuration getPropertyFile(XMLElement el)
        throws IllegalPropertyNameException
    {
        String name = getPropertyString(el);
        if( name == null || name.length() < 1 )
            return null;
        
        try
        {
            return new Configuration(name);
        }
        catch( IOException x )
        {
            throw new IllegalPropertyNameException("Could not open included configuration '"+name+"'");
        }
    }
    
    private void setPropertyFile(XMLElement el, Configuration config)
    {
        el.setAttribute("type","Include");
        if( config.file != null )
            el.setValue(config.file.toString());
    }
    
}
