/*
 * Processor.java
 *
 * Created on May 29, 2003, 12:47 AM
 * Copyright (c) 2003, Sean M. Meiners, sean@ssttr.com
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of SSTTR nor the names of its contributors may be used
 *       to endorse or promote products derived from this software without specific
 *       prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.ssttr.util.processor;

import java.util.Vector;

/**
 * This class implements the features standard to many other ProcessorS.
 * @author  smeiners
 */
abstract class AbstractProcessor
implements Processor
{
    protected int       maxProcessors       = 0;
    protected int       numProcessors       = 0;
    protected int       aliveProcessors     = 0;
    protected int       runningProcessors   = 0;
    protected Vector    processQueue        = null;
    
    /** Creates a new instance of AbstractProcessor that can run <code>tasks</code> simultanious tasks */
    public AbstractProcessor (final int tasks, final int queueSize)
    {
        processQueue = new Vector(queueSize);
        maxProcessors = tasks;
        startup();
    }
    
    public void startup()
    {
        while( numProcessors < maxProcessors )
            addAProcessor();
    }
    
    public boolean shutdown()
    { return shutdown(0); }
    
    public boolean shutdown(int maxWait)
    {
        while( numProcessors > 0 )
            killAProcessor();
        
        if( maxWait > 0 && aliveProcessors > 0 )
        {
            long waitUntil = System.currentTimeMillis() + maxWait;
            while( System.currentTimeMillis() < waitUntil && aliveProcessors > 0 )
            {
                try
                { Thread.sleep(5); }
                catch( InterruptedException x )
                { }
            }
        }
        
        return ( aliveProcessors == 0 );
    }
    
    public int getRunningTasks ()
    {
        return runningProcessors;
    }
    
    public int getQueuedTasks ()
    {
        return processQueue.size();
    }
    
    protected void addAProcessor()
    {
		numProcessors ++;
        new ProcessorThread().start();
    }
    
    protected void killAProcessor()
    {
		numProcessors --;
        process(null);
    }
    
    public synchronized Runnable getTask()
    {
        while( processQueue.size() == 0 )
        {
            try
            { wait(); }
            catch( InterruptedException x )
            { }
        }
        Runnable task = (Runnable)processQueue.elementAt(0);
        processQueue.removeElementAt(0);
        return task;
    }

    protected class ProcessorThread
    extends Thread
    {
        public void run()
        {
            Runnable task = null;
            aliveProcessors ++;

            while( true )
            {
                task = getTask();
                if( task == null )
                    break;

                runningProcessors ++;
                
                try
                {
                    task.run();
                }
                catch( Throwable t )
                {
                    System.err.println("Task "+task+" threw a "+t+": "+t.getMessage());
                    t.printStackTrace();
                }
                
                runningProcessors --;
                
            } // end while(true)
            
            aliveProcessors --;
        }
    }
    
}
