/*
 * ObjectPool.java
 *
 * Created on June 29, 2003, 12:36 AM
 * Copyright (c) 2003, Sean M. Meiners, sean@ssttr.com
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of SSTTR nor the names of its contributors may be used
 *       to endorse or promote products derived from this software without specific
 *       prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.ssttr.util;

import java.util.Vector;

/**
 * A simple class that implements a pool of <code>Object</code>s.
 * @author  smeiners
 */
public class ObjectPool
{
    protected Vector objects    = null;
    protected Vector pool       = null;
    
    /** Creates a new instance of ObjectPool with a <code>size</code> of 10 */
    public ObjectPool ()
    {
        this(10);
    }
    
    /** Creates a new instance of ObjectPool presized to <code>size</code> */
    public ObjectPool (int size)
    {
        objects = new Vector(size);
        pool    = new Vector(size);
    }
    
    /** Returns the current total number of <code>Object</code>s in the pool. */
    public int size()
    {
        return objects.size();
    }
    
    /** Returns the current number of <code>Object</code>s available in the pool. */
    public int available()
    {
        return pool.size();
    }
    
    /** Borrows an <code>Object</code> from the pool.  Make sure to return the <code>Object</code> with <code>returnObject</code> when you are done.
     * @return An <code>Object</code>, or <code>null</code> if the pool is empty.
     */
    public synchronized Object borrowObject()
    {
        if( pool.size() > 0 )
        {
            Thread thread = (Thread)pool.elementAt(0);
            pool.removeElementAt(0);
            return thread;
        }
        return null;
    }
    
    /** Returns an <code>Object</code> to the pool.  This will not accept an <code>Object</code> that was neither added (via <code>addObject</code>) or borrowed (via <code>borrowObject</code>). */
    public synchronized void returnObject(final Object object)
    {
        // make sure the thread is not already in the pool
        // and that it actually belongs to us.
        if( pool.indexOf(object) == -1 && objects.indexOf(object) != -1 )
            pool.addElement(object);
    }
    
    /** Adds an <code>Object</code> to the pool.  This makes the <code>Object</code> available to be borrowed. */
    public synchronized void addObject(final Object object)
    {
        if( objects.indexOf(object) != -1 )
            return; // we already have that one.
        objects.addElement( object );
        pool.addElement( object );
    }
    
    /** Removes an <code>Object</code> from the pool.  This makes the <code>Object</code> unavailable to be borrowed. */
    public synchronized void removeObject(Object object)
    {
        if( objects.indexOf(object) == -1 )
            return; // we don't have that one.
        // We have to remove the object from the list of all objects.
        // this way when the object is returned it won't actually
        // be added back into the pool.
        pool.removeElement(object);
        objects.removeElement(object);
    }
}
