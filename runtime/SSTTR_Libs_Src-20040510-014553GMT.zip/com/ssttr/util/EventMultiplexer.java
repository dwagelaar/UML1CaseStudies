/*
 * EventMultiplexer.java
 *
 * Created on June 27, 2003, 5:35 PM
 * Copyright (c) 2003, Sean M. Meiners, sean@ssttr.com
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of SSTTR nor the names of its contributors may be used
 *       to endorse or promote products derived from this software without specific
 *       prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.ssttr.util;

import java.util.*;

import com.ssttr.util.processor.Processor;

/**
 * This is a handy-dandy class to make building event-driven
 * systems that much easier.  The way it works is you create
 * one or more EventListenerS and register them with the
 * EventMultiplexer to recieve named event(s).  Then, when
 * something happens that should trigger an event you simply call
 * processEvent and it calls on all associated EventListeners
 * to process the event.  Event processing can be done either
 * synchrnously or asynchronously.  This is controlled by whether
 * or not you provide a Processor.  If a Processor is not provided
 * then processEvent will block. 
 * 
 * @author  smeiners
 */
public class EventMultiplexer
{
    protected       Processor       processor       = null;
    protected       Hashtable       events          = null;
    
    protected       Vector          listenerQueue   = null;
    protected       Vector          eventQueue      = null;
    protected       Object          lock            = null;
    protected       EventProcessor  eventProcessor  = null;
    
    /**
     * Creates a new EventMultiplexer with no Processor.
     * All events will be processed synchronously and
     * processEvent will therefore block.
     */
    public EventMultiplexer()
    {
        this(null);
    }
    
    /**
     * Creates a new EventMultiplexer with a Processor.
     * All events will be processed asynchronously and
     * processEvent will return immediately block.
     */
    public EventMultiplexer(Processor processor)
    {
        this.processor = processor;
        
        reset();
    }
    
    /**
     * Dumps all event listeners and returns to the same state
     * as it was in directly after instantiation.
     */
    public synchronized void reset()
    {
        events = new Hashtable(23);
        
        if( processor != null )
        {
            listenerQueue   = new Vector(10);
            eventQueue      = new Vector(10);
            lock            = new Object();
            eventProcessor  = new EventProcessor();
        }
    }

    /**
     * Gets a list of all the event names that have listeners
     * attached to them.
     */
    public synchronized Vector getActiveEventNames()
    {
        Vector eventNames = new Vector(events.size());
        
        String eventName = null;
        
        for( Enumeration e = events.elements(); e.hasMoreElements(); )
        {
            eventName = (String)e.nextElement();
            eventNames.add(eventName);
        }
        
        return eventNames;
    }
    
    /**
     * Gets a list of all the EventListeners that are registered
     * for the given event name.
     */
    public synchronized Vector getRegisteredListeners(String eventName)
    {
        Vector listeners = (Vector)events.get(eventName);
        
        if( listeners != null )
            return new Vector(listeners);
        
        return new Vector(1);
    }
    
    /**
     * Checks to see if any listeners are registered for the given
     * event.  Using this before calling processEvent would not
     * save any time since processEvent already performs this check
     * before attempting to do any work.
     */
    public synchronized boolean listenerRegistered(String eventName)
    {
        return ( events.get(eventName) != null );
    }

    /**
     * Registers an EventListener for the given event name.
     */    
    public synchronized void registerListener(String eventName, EventListener listener)
    {
        Vector listeners = (Vector)events.get(eventName);
        
        if( listeners == null )
        {
            listeners = new Vector(1);
            events.put(eventName,listeners);
        }
        
        if( ! listeners.contains(listener) )
            listeners.addElement(listener);
    }
    
    /**
     * De-registers a given EventListener for the given event name.
     */    
    public synchronized void deregisterListener(String eventName, EventListener listener)
    {
        Vector listeners = (Vector)events.get(eventName);
        
        if( listeners == null )
            return;
        
        listeners.removeElement(listener);
        
        if( listeners.size() < 1 )
            events.remove(eventName);
    }

    /**
     * Attempts to send the given event to all listeners registered
     * for the given event.  If the EventMultiplexer was created
     * with a Processor this will return as soon as it fills its
     * queue, otherwise it won't return until all EventListeners
     * are done processing the event.
     * @throws InterruptedException if the Processor can not process an event.
     */
    public synchronized void processEvent(String eventName, EventObject event)
        throws InterruptedException
    {
        Vector listeners = (Vector)events.get(eventName);
        if( listeners == null || listeners.size() < 1 )
            return;
        
        if( processor == null )
        {
            EventListener listener = null;
            
            for( Enumeration e = listeners.elements(); e.hasMoreElements(); )
            {
                listener = (EventListener)e.nextElement();
                listener.processEvent(event);
            }
        }
        else
        {
            EventListener listener = null;
            
            for( Enumeration e = listeners.elements(); e.hasMoreElements(); )
            {
                listener = (EventListener)e.nextElement();
                
                synchronized( lock )
                {
                    eventQueue.addElement(event);
                    listenerQueue.addElement(listener);
                }
                
                if( ! processor.process(eventProcessor) )
                    throw new InterruptedException("Processor refused to process event.");
            }
        }
    }
    
    private class EventProcessor
    implements Runnable
    {
        private     EventListener   listener    = null;
        private     EventObject     event       = null;
            
        public void run()
        {
            synchronized( lock )
            {
                listener = (EventListener)listenerQueue.elementAt(0);
                event    = (EventObject)eventQueue.elementAt(0);
                
                listenerQueue.removeElementAt(0);
                eventQueue.removeElementAt(0);
            }
            
            listener.processEvent(event);
        }
    }
}
