/*
 * DOMParser.java
 *
 * Created on April 29, 2003, 8:20 PM
 * Copyright (c) 2003, Sean M. Meiners, sean@ssttr.com
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of SSTTR nor the names of its contributors may be used
 *       to endorse or promote products derived from this software without specific
 *       prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.ssttr.xml;

import java.io.*;
import java.net.URL;
import java.util.*;

/**
 * This class is really just an implementation of {@link SAXInterface} that
 * gets passed to a coresponding {@link SAXParser} for the sake of creating
 * a DOM version of the given XML docuement.
 * @author  smeiners
 */
public class DOMParser
implements SAXInterface
{
//    private static final boolean DEBUG = true;
    private static final boolean DEBUG = false;
    
    SAXParser   parser  = null;
    XMLElement  el      = null;
    Stack       elStack = null;
        
    /**
     * Creates a new instance of DOMParser which can be reused as many
     * times as you like, just don't try to use one instance from more
     * than one thread at a time.
     */
    public DOMParser ()
    {
    }

	/**
	 * Parses the given file.
	 * @return The root element of the document.
     * @throws NullPointerException if file == null.
     * @throws ParserException when it encounters bad XML.
     * @throws IOException when there is a problem reading from the XML stream.
	 */
    public XMLElement parse(File file)
    	throws NullPointerException, ParserException, IOException
    {
    	if( file == null )
    		throw new NullPointerException("file == null");
    		
    	return parse(new FileInputStream(file));
    }
    
	/**
	 * Attempts to open the given URL and parse the resulting stream.
	 * @return The root element of the document.
	 * @throws NullPointerException if file == null.
	 * @throws ParserException when it encounters bad XML.
	 * @throws IOException when there is a problem reading from the XML stream.
	 */
    public XMLElement parse(URL url)
    	throws NullPointerException, ParserException, IOException
    {
		if( url == null )
			throw new NullPointerException("url == null");
    		
    	return parse(url.openStream());
    }
    
	/**
	 * Parses the given stream.
	 * @return The root element of the document.
	 * @throws NullPointerException if xml == null.
	 * @throws ParserException when it encounters bad XML.
	 * @throws IOException when there is a problem reading from the XML stream.
	 */
    public XMLElement parse(InputStream xml)
    	throws NullPointerException, ParserException, IOException
    {
		if( xml == null )
			throw new NullPointerException("xml == null");
			
        DataInputStream in;
        if( xml instanceof DataInputStream )
            in = (DataInputStream)xml;
        else
            in = new DataInputStream(xml);
        
        elStack = new Stack();

        parser = new SAXParser(this);
        try
        { parser.parse (in); }
        catch( EOFException x )
        { } // this is ok, we expect it to end.

        XMLElement root = null;
        
        if( elStack.size() > 0 )
            root = (XMLElement)elStack.pop();
        
        parser = null;
        el = null;
        elStack = null;
        
        return root;
    }
        
    public void cData (String data)
    {
        if( DEBUG )
            System.out.println("cData: '"+data+"'");

        el = (XMLElement)elStack.peek();
        el.appendValue(data);
    }

    public void chunkStart (String tag, Hashtable attrs)
    {
        if( DEBUG )
            System.out.println("chunkStart "+tag);

		elementStart(tag,attrs);
    }

    public void docStart (String tag, Hashtable attrs)
    {
        if( DEBUG )
            System.out.println("docStart " + tag + " = " + attrs);

        el = new XMLElement(tag,attrs);

        elStack.push(el);
    }

    public void elementStart (String tag, Hashtable attrs)
    {
        if( DEBUG )
            System.out.println("elementStart: '"+tag+"' "+attrs);


        el = new XMLElement(tag,attrs);
        
        ((XMLElement)elStack.peek()).addChild(el);

        elStack.push(el);
    }

    public void elementStop (String tag)
    {
        if( DEBUG )
            System.out.println("elementStop: '"+tag+"'");

        elStack.pop();
    }

    public void chunkStop (String tag)
    {
        if( DEBUG )
            System.out.println("chunkStop: '"+tag+"'");

        elementStop(tag);
    }

    public void docStop (String tag)
    {
        if( DEBUG )
            System.out.println("docStop "+tag);

        // Don't pop here, it would remove the root element, and we need that.
    }

    public void processingInstruction (String element)
    {
        if( DEBUG )
            System.out.println("pI: '"+element+"'");
    }

    public void dtdData (String dtd)
    {
        if( DEBUG )
            System.out.println("dtdData: '"+dtd+"'");
    }
        
}
