/*
 * Main.java
 *
 * Created on April 25, 2002, 7:08 PM
 */

package com.jabberwookie.tests;

import java.net.Socket;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Enumeration;

import com.ssttr.xml.XMLElement;

import com.jabberwookie.Client2Server;
import com.jabberwookie.IQListener;
import com.jabberwookie.MessageListener;
import com.jabberwookie.PresenceListener;

import com.jabberwookie.ns.jabber.Const;
import com.jabberwookie.ns.jabber.Chunk;
import com.jabberwookie.ns.jabber.IQ;
import com.jabberwookie.ns.jabber.Message;
import com.jabberwookie.ns.jabber.Presence;

import com.jabberwookie.ns.jabber.iq.IQRegister;
import com.jabberwookie.ns.jabber.iq.IQRoster;

/**
 * This class is part Client2Server test and part usage example.
 * So if you're trying to figure out how this all works, take
 * a look inside.
 * @author  smeiners
 */
public class ClientConnect
implements MessageListener, PresenceListener, IQListener
{
    private Client2Server c2s;
    
    public static void main(String args[])
    {
        if( args.length < 5 )
        {
            System.out.println("usage: <user name> <resource> <password> <server name> <server port>");
            return;
        }
        else
            new ClientConnect(args[0],args[1],args[2],args[3],Integer.parseInt(args[4]));
    }
    
    public ClientConnect (String userName, String resource,
    String password, String serverName, int serverPort)
    {
        if( ! login(userName, resource, password, serverName, serverPort) )
        {
            System.out.println("Could not login.");
            System.exit(1);
        }
        
        System.out.println("Logged in!");
    }

    /**
     * This will attempt to login to the Jabber server.  If it fails
     * because the given username does not exist it will attempt
     * to create that user.
     * @param userName
     * @param resource
     * @param password
     * @param serverName
     * @param serverPort
     * @return
     */    
    public boolean login
    (String userName, String resource, String password, String serverName, int serverPort)
    {
        try
        {
            // First, open a socket to the server.
            Socket s = new Socket (serverName, serverPort);
            // Then create a Stream object.
            c2s = new Client2Server( s.getInputStream(), s.getOutputStream() );
            // Then open the Jabber stream.
            if( ! c2s.open(serverName,60000) )
		{
		    System.out.println("Could not establish stream after 60 seconds");
		    return false;
		}
            // And make sure to set ourselves up to listen for incoming packets.
            c2s.setAllListeners(this);

            // Now try to login using any method the server supports.
            switch( c2s.loginAny(userName, resource, password, 30) )
            {
                case Client2Server.LOGIN_BAD_PASS:
                    System.out.println("Bad password.");
                    return false;
                case Client2Server.LOGIN_BAD_UID:
                    // oops, that user doesn't exist, let's create them.
                    if( ! registerUser(userName,password) )
                        return false;
                    // and now that they exist, try again.
                    else if( c2s.loginAny(userName, resource, password, 30) < Client2Server.LOGIN_OK )
                        return false;
                    
                    break;
                case Client2Server.LOGIN_FAILED:
                    System.out.println("Login failed: unknown.");
                    return false;
                case Client2Server.LOGIN_OK:
                    // sucess!!
                    break;
                case Client2Server.LOGIN_PASS_EXP:
                    System.out.println("Your password has expired, please change it now.");
                    break;
            }
            
            // set our presence
            c2s.send( new Presence(Const.CHAT,"Available",1) );
            
            // request the user's roster.  this has to be done
            // after we set our presence, otherwise we'll never get it.
            c2s.send( IQRoster.createGetRequest(), 30 );
            
            return true;
        }
        catch( IOException x )
        {
            // hmm, a connection problem.
            x.printStackTrace();
            return false;
        }
    }

    public void incomingIQ (IQ iq)
    {
        // we got an <iq> packet     
        XMLElement el = iq.getChild(0);
        if( el instanceof IQRoster )
        {
            // it's our roster!
            for( Enumeration items = el.enumerateChildren(); items.hasMoreElements(); )
            {
                System.out.println( "Roster Item: " + (IQRoster.Item)items.nextElement() );
            }
        }
    }
    
    public void incomingMessage (Message message)
    {
        // yay!  someone sent us a message!
        System.out.println("Message: " + message);
    }
    
    public void incomingPresence (Presence presence)
    {
        // we got a <presence> packet
        final String type = presence.getType();
        
        // check to see if it's valid, some users send bad presence data
        if( type == null || type.length() < 1 )
            return;
        
        if( type.equals(Const.SUBSCRIBE) )
        {
            // someone wants to subscribe to our presence
            // so we slightly re-write the packet to send back 
            presence.setType(Const.SUBSCRIBED);
            System.out.println(presence.getFrom() + " wants to subscribe to your presence, allowing.");
        }

        else if( type.equals(Const.UNSUBSCRIBE) )
        {
            // someone wants to unsuscribe from our presence
            // so we slightly re-write the packet to send back 
            presence.setType(Const.UNSUBSCRIBED);
            System.out.println(presence.getFrom() + " wants to unsubscribe to your presence, allowing.");
        }
        
        else
        {
            // just a normal presence notification
            System.out.println("Presence:" + presence);
            return;
        }

        // make sure to return it to the sender and not ourselves
        presence.setTo( presence.getFrom() );
        
        try
        { c2s.send (presence); }
        catch( IOException x )
        { x.printStackTrace(); }
    }
    
    private boolean registerUser(String userName, String password)
    {
        System.out.println("You are not registered, attempting to do so now.");
        try
        {
            Hashtable info = IQRegister.getRequiredRegInfo(c2s);
            info.put(Const.USERNAME,userName);
            info.put(Const.PASSWORD,password);

            System.out.println("The Server wants the following info:");
            String key, value;
            for( Enumeration e = info.keys(); e.hasMoreElements(); )
            {
                key = (String)e.nextElement();
                value = (String)info.get(key);
                
                System.out.println(key + "=" + value + ".");
                
                // the server could ask for more than these three
                // parameters, but unless we ask the user we'll have
                // no idea what to give it.
                if( key.equals(Const.USERNAME) )
                    info.put(key,userName);
                else if( key.equals(Const.PASSWORD) )
                    info.put(key,password);
                // the default jabberd config *requires* an
                // email address, so we'll placate it.
                else if( key.equals(Const.EMAIL) )
                    info.put(key, "bogus@email.address" );
            }
            
            Chunk chunk = c2s.send
            ( IQRegister.createSetRequest(c2s.getServerName(), info), 30 );
            
            // verify sucess
            return ( chunk != null && chunk.getType().equals(Const.RESULT) );
        }
        catch( IOException x )
        { return false; }
    }
}
