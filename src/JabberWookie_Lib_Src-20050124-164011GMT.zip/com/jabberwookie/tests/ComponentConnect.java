/*
 * ComponentConnect.java
 *
 * Created on June 16, 2003, 4:50 PM
 * Copyright (c) 2003, Sean M. Meiners, sean@jabberwookie.com
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *     * Neither the name of JabberWookie nor the names of its contributors may be used
 *       to endorse or promote products derived from this software without specific
 *       prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jabberwookie.tests;

import java.net.Socket;
import java.io.IOException;

import com.jabberwookie.Component2Server;
import com.jabberwookie.IQListener;
import com.jabberwookie.MessageListener;
import com.jabberwookie.PresenceListener;
import com.jabberwookie.UnrecognizedChunkListener;

import com.jabberwookie.ns.jabber.IQ;
import com.jabberwookie.ns.jabber.Chunk;
import com.jabberwookie.ns.jabber.Message;
import com.jabberwookie.ns.jabber.Presence;

/**
 * Just attempts to connect to a Jabber server as a component.
 * just run 'java -cp JabberWookie.jar com.jabberwookie.tests.ComponentConnect'
 * to see the command-line help. 
 * @author  smeiners
 */
public class ComponentConnect
implements IQListener, PresenceListener, MessageListener, UnrecognizedChunkListener
{
    
    public static void main(String args[])
    throws Exception
    {
        if( args.length < 5 )
            System.out.println("Usage: <server name/ip> <server port> <domain> <timeout> <secret>");
        else
            new ComponentConnect(args[0], Integer.parseInt(args[1]), args[2], Integer.parseInt(args[3]), args[4]);
    }
    
    /** Creates a new instance of ComponentConnect */
    public ComponentConnect (String server, int port, String host, int timeout, String secret)
    throws IOException
    {
        Socket s = new Socket (server, port);
        Component2Server c2s = new Component2Server( s.getInputStream(), s.getOutputStream(), secret );
        c2s.setAllListeners(this);
        c2s.setUnrecogizedChunkListener(this);
        System.out.println("Opened = " + c2s.open( host, timeout ) );
    }
    
    public void incomingIQ (IQ iq)
    {
        System.out.println("IQ:"+iq);
    }
    
    public void incomingMessage (Message message)
    {
        System.out.println("Message:"+message);
    }
    
    public void incomingPresence (Presence presence)
    {
        System.out.println("Presence:"+presence);
    }
    
    public void incomingChunk (Chunk chunk)
    {
        System.out.println("Unrecognized:"+chunk);
    }
    
}
